//
//  MainPresenter.swift
//  KhanMobileEffect
//
//  Created by Alikhan Tursunbekov on 4/6/25.
//

class MainPresenter {
    
}
