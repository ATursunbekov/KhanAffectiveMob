//
//  ViewController.swift
//  KhanMobileEffect
//
//  Created by Alikhan Tursunbekov on 1/6/25.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemPink
    }
}
